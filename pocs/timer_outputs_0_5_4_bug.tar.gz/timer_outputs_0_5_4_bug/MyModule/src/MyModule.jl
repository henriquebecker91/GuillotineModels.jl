module MyModule

using TimerOutputs

function a()
	sleep(0.25)
	@timeit "sleep(0.5)" sleep(0.5)
	return
end
export a

end
