#!/bin/bash
# -*- mode: julia -*-
#=
exec julia --project=@. --color=yes --startup-file=no -e "include(popfirst!(ARGS))" "${BASH_SOURCE[0]}" "$@"
=#

using MyModule
import TimerOutputs

function reproducer()
	a()
end

reproducer()

TimerOutputs.print_timer() # global timer used
println()

